"""
YOLOv8n 迁移学习训练脚本
数据集：仿真生成的探地雷达B-scan图像，目标为地下PVC管道
"""

import argparse
import os
from pathlib import Path
import torch
from ultralytics import YOLO, RTDETR
# Windows 多进程 DLL 加载修复
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

# ======================== 配置 ========================
ROOT = Path(__file__).resolve().parent
DATASET_DIR = ROOT.parent / "dataset_grouped"
data_yaml = DATASET_DIR / "data.yaml"


def pick_device():
    forced = os.environ.get("FORCE_DEVICE")
    if forced:
        return forced
    if torch.cuda.is_available():
        return "cuda"
    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


# ======================== 训练 ========================
def train(args):

    if args.model_type.lower() == "yolo":
        model = YOLO(args.yolo_weight)
        run_name = args.run_name or "yolov8n_big"
    elif args.model_type.lower() == "rtdetr":
        model = RTDETR(args.rtdetr_weight)
        run_name = args.run_name or "rtdetr_l"
    else:
        raise ValueError(
            f"Unsupported model_type: {args.model_type}"
        )

    model.train(
        data=str(args.data),
        epochs=args.epochs,
        batch=args.batch_size,
        workers=args.workers,
        imgsz=args.imgsz,
        device=args.device,
        project=str(ROOT / "runs"),
        name=run_name,
        optimizer="AdamW",
        lr0=0.0002,
        lrf=0.01,
        warmup_epochs=5,
        augment=True,
        fliplr=0.5,
        patience=args.patience,
        amp=False,
    )

    print(
        f"训练完成！最佳权重保存在 "
        f"runs/{run_name}/weights/best.pt"
    )

    return model


# ======================== 主流程 ========================
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_type", default="yolo", choices=["yolo", "rtdetr"])
    parser.add_argument("--data", default=str(data_yaml))
    parser.add_argument("--yolo_weight", default=str(ROOT / "yolov8n.pt"))
    parser.add_argument("--rtdetr_weight", default="rtdetr-l.pt")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--patience", type=int, default=20)
    parser.add_argument("--device", default=None, help="cuda|mps|cpu|0,1,... (default: auto-detect, honors FORCE_DEVICE env)")
    parser.add_argument("--run_name", default=None)
    args = parser.parse_args()
    if args.device is None:
        args.device = pick_device()
    train(args)


