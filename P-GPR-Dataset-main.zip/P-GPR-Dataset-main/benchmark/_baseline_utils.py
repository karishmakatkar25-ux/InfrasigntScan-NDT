# -*- coding: utf-8 -*-
"""Shared helpers for the Train$benchmark baseline scripts.

Reconstructed from how train_faster_rcnn.py / train_retinanet.py / benchmark.py
call it -- the original module was never committed alongside those scripts.
"""

import os

import numpy as np

IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp")

C_LIGHT = 3.0e8  # m/s


def list_images(img_dir):
    """Sorted list of full paths to every image file in img_dir."""
    files = []
    for name in os.listdir(img_dir):
        if os.path.splitext(name)[1].lower() in IMAGE_EXTS:
            files.append(os.path.join(img_dir, name))
    files.sort()
    return files


def yolo_label_path_for_image(img_path):
    """<split>/images/x.png -> <split>/labels/x.txt (adjacent 'labels' dir)."""
    img_dir = os.path.dirname(img_path)
    label_dir = os.path.join(os.path.dirname(img_dir), "labels")
    stem = os.path.splitext(os.path.basename(img_path))[0]
    return os.path.join(label_dir, stem + ".txt")


def load_yolo_label(label_path, w, h):
    """YOLO normalized `cls cx cy bw bh` lines -> [cls, x1, y1, x2, y2] pixel boxes."""
    labels = []
    if not os.path.exists(label_path):
        return labels
    with open(label_path, "r") as f:
        for line in f:
            parts = line.split()
            if len(parts) != 5:
                continue
            cls, xc, yc, bw, bh = parts
            cls = int(cls)
            xc, yc, bw, bh = float(xc), float(yc), float(bw), float(bh)
            x1 = (xc - bw / 2) * w
            y1 = (yc - bh / 2) * h
            x2 = (xc + bw / 2) * w
            y2 = (yc + bh / 2) * h
            labels.append([cls, x1, y1, x2, y2])
    return labels


def depth_per_pixel(img_h, time_window, epsilon_r):
    """Meters per vertical pixel for a B-scan of height img_h.

    Two-way travel time per pixel row is time_window / img_h; depth follows the
    standard GPR relation depth = c * t / (2 * sqrt(epsilon_r)).
    """
    dt = time_window / img_h
    return C_LIGHT * dt / (2.0 * np.sqrt(epsilon_r))


def _iou(box_a, box_b):
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0.0, ix2 - ix1), max(0.0, iy2 - iy1)
    inter = iw * ih
    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    union = area_a + area_b - inter
    return inter / union if union > 0 else 0.0


def _voc_ap(recall, precision):
    """All-point interpolated AP (VOC 2010+ / COCO-style monotonic envelope)."""
    mrec = np.concatenate(([0.0], recall, [1.0]))
    mpre = np.concatenate(([0.0], precision, [0.0]))
    for i in range(mpre.size - 1, 0, -1):
        mpre[i - 1] = max(mpre[i - 1], mpre[i])
    idx = np.where(mrec[1:] != mrec[:-1])[0]
    return float(np.sum((mrec[idx + 1] - mrec[idx]) * mpre[idx + 1]))


def compute_ap(preds_pc, gts_pc, iou_thr=0.5):
    """Single-class AP over a dataset.

    preds_pc: {image_name: [(score, x1, y1, x2, y2), ...]}
    gts_pc:   {image_name: [(x1, y1, x2, y2), ...]}

    Returns (ap, precision, recall, TP, FP, n_gt) -- precision/recall are the
    values at the operating point implied by all supplied predictions (i.e. at
    the score threshold the caller already filtered to), matching how the
    baseline scripts report a single P/R alongside the AP curve.
    """
    n_gt = sum(len(v) for v in gts_pc.values())

    detections = []
    for name, preds in preds_pc.items():
        for score, x1, y1, x2, y2 in preds:
            detections.append((score, name, (x1, y1, x2, y2)))
    detections.sort(key=lambda d: -d[0])

    matched = {name: np.zeros(len(boxes), dtype=bool) for name, boxes in gts_pc.items()}

    tp = np.zeros(len(detections))
    fp = np.zeros(len(detections))

    for i, (_score, name, box) in enumerate(detections):
        gt_boxes = gts_pc.get(name, [])
        best_iou, best_j = 0.0, -1
        for j, gt_box in enumerate(gt_boxes):
            if matched[name][j]:
                continue
            iou = _iou(box, gt_box)
            if iou > best_iou:
                best_iou, best_j = iou, j
        if best_iou >= iou_thr and best_j >= 0:
            tp[i] = 1
            matched[name][best_j] = True
        else:
            fp[i] = 1

    tp_cum = np.cumsum(tp)
    fp_cum = np.cumsum(fp)
    recall = tp_cum / max(n_gt, 1)
    precision = tp_cum / np.maximum(tp_cum + fp_cum, 1e-9)

    ap = _voc_ap(recall, precision) if len(detections) else 0.0

    TP = int(tp.sum())
    FP = int(fp.sum())
    P = TP / max(TP + FP, 1)
    R = TP / max(n_gt, 1)

    return ap, P, R, TP, FP, n_gt


def vertex_eval(preds_m, gts_m, match_thresh):
    """Greedy nearest-neighbor matching of (x, y) points in meters.

    preds_m, gts_m: lists of (x, y) tuples.
    match_thresh: max Euclidean distance (m) to count as a match.

    Returns (TP, FP, FN, pairs) where pairs is
    [(pred_x, pred_y, gt_x, gt_y), ...] for every matched pair.
    """
    n_pred, n_gt = len(preds_m), len(gts_m)
    if n_pred == 0:
        return 0, 0, n_gt, []
    if n_gt == 0:
        return 0, n_pred, 0, []

    cands = []
    for pi, (px, py) in enumerate(preds_m):
        for gi, (gx, gy) in enumerate(gts_m):
            d = float(np.hypot(px - gx, py - gy))
            if d <= match_thresh:
                cands.append((d, pi, gi))
    cands.sort(key=lambda c: c[0])

    used_pred, used_gt = set(), set()
    pairs = []
    for _d, pi, gi in cands:
        if pi in used_pred or gi in used_gt:
            continue
        used_pred.add(pi)
        used_gt.add(gi)
        px, py = preds_m[pi]
        gx, gy = gts_m[gi]
        pairs.append((px, py, gx, gy))

    TP = len(pairs)
    FP = n_pred - TP
    FN = n_gt - TP
    return TP, FP, FN, pairs
