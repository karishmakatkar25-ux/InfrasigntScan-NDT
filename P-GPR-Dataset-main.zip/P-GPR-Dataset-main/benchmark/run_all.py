# -*- coding: utf-8 -*-
"""Run all four baselines (YOLOv8n, RT-DETR, Faster R-CNN, RetinaNet) on
dataset_grouped, then run benchmark.py -- for unattended execution on a
CPU-only server.

Each model is trained as an independent subprocess so a crash in one model
does not stop the others. Logs are written to logs/<model>.log. Any weight
that already exists is skipped by default (resume-friendly); pass
--force to retrain everything.

Usage:
  python run_all.py                          # train all 4 + benchmark, defaults
  python run_all.py --models yolo frcnn       # only these
  python run_all.py --epochs 60 --patience 15
  python run_all.py --skip-train              # benchmark only (reuses existing weights)
  python run_all.py --skip-benchmark          # train only
  python run_all.py --force                   # retrain even if weights exist
"""
import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATASET_DIR = ROOT.parent / "dataset_grouped"
DATA_YAML = DATASET_DIR / "data.yaml"
LOG_DIR = ROOT / "logs"

MODEL_CHOICES = ["yolo", "rtdetr", "frcnn", "retinanet"]

WEIGHT_PATHS = {
    "yolo": ROOT / "runs" / "yolov8n_big" / "weights" / "best.pt",
    "rtdetr": ROOT / "runs" / "rtdetr_l" / "weights" / "best.pt",
    "frcnn": ROOT / "runs" / "frcnn" / "best.pth",
    "retinanet": ROOT / "runs" / "retinanet" / "best.pth",
}


def run_logged(cmd, log_path, env):
    print(f"[run] {' '.join(str(c) for c in cmd)}")
    print(f"      -> log: {log_path}")
    t0 = time.time()
    with open(log_path, "w", encoding="utf-8") as f:
        proc = subprocess.run(cmd, cwd=str(ROOT), stdout=f, stderr=subprocess.STDOUT, env=env)
    dt = time.time() - t0
    status = "OK" if proc.returncode == 0 else f"FAILED (exit {proc.returncode})"
    print(f"[done] {log_path.name}: {status} in {dt/60:.1f} min")
    return proc.returncode == 0


def train_one(model, args, env):
    weight = WEIGHT_PATHS[model]
    if weight.exists() and not args.force:
        print(f"[skip] {model}: weight already exists at {weight} (use --force to retrain)")
        return True

    LOG_DIR.mkdir(exist_ok=True)
    log_path = LOG_DIR / f"{model}.log"

    if model == "yolo":
        cmd = [
            sys.executable, str(ROOT / "train_yolo&rtdetr.py"),
            "--model_type", "yolo",
            "--data", str(DATA_YAML),
            "--epochs", str(args.epochs),
            "--batch_size", str(args.batch_size),
            "--imgsz", str(args.imgsz),
            "--patience", str(args.patience),
            "--device", args.device,
        ]
    elif model == "rtdetr":
        cmd = [
            sys.executable, str(ROOT / "train_yolo&rtdetr.py"),
            "--model_type", "rtdetr",
            "--data", str(DATA_YAML),
            "--epochs", str(args.epochs),
            "--batch_size", str(max(args.batch_size // 2, 1)),
            "--imgsz", str(args.imgsz),
            "--patience", str(args.patience),
            "--device", args.device,
        ]
    elif model == "frcnn":
        cmd = [
            sys.executable, str(ROOT / "train_faster_rcnn.py"), "train",
            "--data", str(DATASET_DIR),
            "--epochs", str(args.epochs),
            "--batch_size", str(max(args.batch_size // 4, 1)),
            "--out", str(ROOT / "runs" / "frcnn"),
            "--num_workers", str(args.num_workers),
            "--patience", str(args.patience),
        ]
    elif model == "retinanet":
        cmd = [
            sys.executable, str(ROOT / "train_retinanet.py"),
            "--data", str(DATASET_DIR),
            "--epochs", str(args.epochs),
            "--batch_size", str(max(args.batch_size // 2, 1)),
            "--out", str(ROOT / "runs" / "retinanet"),
            "--num_workers", str(args.num_workers),
            "--patience", str(args.patience),
        ]
    else:
        raise ValueError(model)

    return run_logged(cmd, log_path, env)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", nargs="+", choices=MODEL_CHOICES, default=MODEL_CHOICES,
                     help="Which models to train (default: all four)")
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--batch_size", type=int, default=8,
                     help="Base batch size for YOLO; other models scale down from this")
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--patience", type=int, default=20)
    ap.add_argument("--num_workers", type=int, default=4)
    ap.add_argument("--device", default="cuda", help="cpu|cuda|mps")
    ap.add_argument("--threads", type=int, default=0,
                     help="torch intra-op CPU threads (0 = library default, i.e. all cores)")
    ap.add_argument("--force", action="store_true", help="Retrain even if best weight already exists")
    ap.add_argument("--skip-train", action="store_true")
    ap.add_argument("--skip-benchmark", action="store_true")
    args = ap.parse_args()

    env = os.environ.copy()
    env["FORCE_DEVICE"] = args.device
    env["KMP_DUPLICATE_LIB_OK"] = "True"
    if args.threads > 0:
        env["OMP_NUM_THREADS"] = str(args.threads)
        env["MKL_NUM_THREADS"] = str(args.threads)

    print(f"[config] device={args.device} epochs={args.epochs} batch_size={args.batch_size} "
          f"patience={args.patience} models={args.models}")
    print(f"[data] {DATA_YAML}")

    if not args.skip_train:
        results = {}
        for model in args.models:
            results[model] = train_one(model, args, env)
        print("\n[summary] training results:")
        for model, ok in results.items():
            print(f"  {model:10s} {'OK' if ok else 'FAILED'}")

    if not args.skip_benchmark:
        LOG_DIR.mkdir(exist_ok=True)
        bench_log = LOG_DIR / "benchmark.log"
        cmd = [sys.executable, str(ROOT / "benchmark.py")]
        run_logged(cmd, bench_log, env)


if __name__ == "__main__":
    main()
